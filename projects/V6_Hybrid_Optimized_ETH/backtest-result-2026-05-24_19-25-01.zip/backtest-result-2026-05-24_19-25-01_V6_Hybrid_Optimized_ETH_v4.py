import logging
import numpy as np
import pandas as pd
from pandas import DataFrame
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, BooleanParameter
import talib.abstract as ta
from datetime import datetime, timedelta, timezone
from freqtrade.persistence import Trade

logger = logging.getLogger(__name__)

GLOBAL_DATAFRAMES = {}

class V6_Hybrid_Optimized_ETH_v4(IStrategy):
    INTERFACE_VERSION = 3

    # 전략 설정
    can_short: bool = True
    timeframe = '4h'
    startup_candle_count: int = 200
    
    # FreqAI 관련 설정
    process_only_new_candles = True
    use_exit_signal = True

    # 하이퍼옵트 파라미터 선언 (이더리움 특화형 v4)
    adx_long = IntParameter(10, 40, default=20, space='buy', optimize=True) # 22 -> 20 완화
    adx_short = IntParameter(15, 45, default=22, space='buy', optimize=True) # 30 -> 22 완화
    rsi_long = IntParameter(40, 70, default=42, space='buy', optimize=True) # 45 -> 42 완화
    rsi_short = IntParameter(30, 60, default=45, space='buy', optimize=True) # 40 -> 45 완화
    prediction_threshold = DecimalParameter(0.005, 0.050, default=0.008, space='buy', decimals=3, optimize=True) # 0.012 -> 0.008 완화 (롱 복리 가속)
    prediction_short_threshold = DecimalParameter(0.002, 0.030, default=0.006, space='buy', decimals=3, optimize=True) # 0.015 -> 0.006 완화 (숏 헤지 복원)

    # ROI: AI가 관리하므로 유연하게 적용
    minimal_roi = {
        "0": 0.40,
        "480": 0.20,
        "960": 0.10
    }

    # 레버리지 파라미터 분리 (이더리움 특화 비대칭 레버리지 v4)
    leverage_long = IntParameter(1, 10, default=9, space='buy', optimize=True) # 8배 -> 9배 상향 (롱 극대화)
    leverage_short = IntParameter(1, 10, default=7, space='buy', optimize=True) # 5배 -> 7배 상향 (숏 펌핑 복원)
    
    stoploss = -0.08 

    # 수수료 및 손절 연동형 시장가 최적화 설정 주입
    order_types = {
        "entry": "limit",
        "exit": "market",
        "emergency_exit": "market",
        "force_entry": "market",
        "force_exit": "market",
        "stoploss": "market",
        "stoploss_on_exchange": True,
        "stoploss_price_type": "last",
        "stoploss_on_exchange_limit_ratio": 0.99
    }

    # 미체결 타임아웃 고속화 주입
    unfilledtimeout = {
        "entry": 2,
        "exit": 5,
        "unit": "minutes"
    }

    _entry_retries = {}

    def confirm_trade_entry(self, pair: str, order_type: str, amount: float, rate: float,
                            time_in_force: str, current_time: datetime, entry_tag: str | None,
                            side: str, **kwargs) -> bool:
        if order_type == 'market':
            logger.info(f"⚡ [Market Fallback] {pair} 시장가 진입 강제 집행 및 상태 리셋.")
            self.order_types['entry'] = 'limit'
            self._entry_retries[pair] = 0
        else:
            if pair not in self._entry_retries:
                self._entry_retries[pair] = 0
            self.order_types['entry'] = 'limit'
            
        return True

    def check_entry_timeout(self, pair: str, trade: Trade, order: 'Order',
                            current_time: datetime, **kwargs) -> bool:
        retry_interval = 10 
        max_retries = 3

        order_date = order.order_date.replace(tzinfo=timezone.utc) if order.order_date.tzinfo is None else order.order_date
        current_date = current_time.replace(tzinfo=timezone.utc) if current_time.tzinfo is None else current_time
        elapsed_seconds = (current_date - order_date).total_seconds()

        if elapsed_seconds > retry_interval:
            retries = self._entry_retries.get(pair, 0)
            
            if retries < (max_retries - 1):
                self._entry_retries[pair] = retries + 1
                logger.info(f"🔁 [Limit Chase {retries + 1}/{max_retries}] {pair} 지정가 미체결 취소 및 다음 틱 호가 갱신 시도. (경과: {elapsed_seconds:.1f}초)")
                return True 
            
            else:
                self._entry_retries[pair] = max_retries
                self.order_types['entry'] = 'market'
                logger.warning(f"🚨 [Limit Chase 최종 실패] {pair} 지정가 {max_retries}회 시도 실패. 즉시 시장가(Market) 진입으로 런타임 전환! (경과: {elapsed_seconds:.1f}초)")
                return True 

        return False

    # 트레일링 스탑
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.05
    trailing_only_offset_is_reached = True

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str,
                 side: str, **kwargs) -> float:
        if side == 'short':
            return float(self.leverage_short.value)
        return float(self.leverage_long.value)

    # -------------------------------------------------------------------------
    # FreqAI: 피처 엔지니어링 (학습 데이터 생성)
    # -------------------------------------------------------------------------
    def feature_engineering_expand_all(self, dataframe: DataFrame, period: int,
                                       metadata: dict, **kwargs) -> DataFrame:
        dataframe[f"%-ema_{period}"] = ta.EMA(dataframe, timeperiod=period)
        dataframe[f"%-rsi_{period}"] = ta.RSI(dataframe, timeperiod=period)
        macd = ta.MACD(dataframe)
        dataframe[f"%-macd_{period}"] = macd['macd']
        dataframe[f"%-macdhist_{period}"] = macd['macdhist']
        dataframe[f"%-atr_{period}"] = ta.ATR(dataframe, timeperiod=period)
        dataframe[f"%-pct_change_{period}"] = dataframe['close'].pct_change(period)
        return dataframe

    def feature_engineering_expand_basic(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        dataframe["%-day_of_week"] = dataframe["date"].dt.dayofweek
        dataframe["%-hour_of_day"] = dataframe["date"].dt.hour
        return dataframe

    def set_freqai_targets(self, dataframe: DataFrame, metadata: dict, **kwargs) -> DataFrame:
        dataframe["&-target_roi"] = (
            dataframe["close"].shift(-6) / dataframe["close"] - 1
        )
        return dataframe

    # -------------------------------------------------------------------------
    # 지표 및 신호
    # -------------------------------------------------------------------------
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # FreqAI 예측 수행
        dataframe = self.freqai.start(dataframe, metadata, self)
        
        # 기본 지표
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['tema'] = ta.TEMA(dataframe, timeperiod=9)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['ema150'] = ta.EMA(dataframe, timeperiod=150) # v4: 중장기 이평선 복구
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)
        dataframe['fastEMA'] = ta.EMA(dataframe, timeperiod=8)
        dataframe['slowEMA'] = ta.EMA(dataframe, timeperiod=24)
        
        # MACD 직접 계산
        macd = ta.MACD(dataframe)
        dataframe['macdhist'] = macd['macdhist']
        
        GLOBAL_DATAFRAMES[metadata['pair']] = dataframe.copy()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        prediction_threshold_val = self.prediction_threshold.value
        prediction_short_threshold_val = self.prediction_short_threshold.value
        adx_long_val = self.adx_long.value
        adx_short_val = self.adx_short.value
        rsi_long_val = self.rsi_long.value
        rsi_short_val = self.rsi_short.value
        di_limit = 0.5               
        
        if 'DI_ratio' not in dataframe.columns:
            dataframe['DI_ratio'] = 0.0
        if 'do_predict' not in dataframe.columns:
            dataframe['do_predict'] = 0

        # Long Entry: AI 예측 + rsi + adx_long + tema 정배열 필터
        dataframe.loc[
            (
                (dataframe['do_predict'] == 1) &
                (dataframe['DI_ratio'] < di_limit) &
                (dataframe['&-target_roi'] > prediction_threshold_val) & # v4: 0.008 완화
                (dataframe['rsi'] > rsi_long_val) & # v4: 42 완화
                (dataframe['adx'] > adx_long_val) & # v4: 20 완화
                (dataframe['tema'] > dataframe['ema200'])
            ),
            'enter_long'] = 1

        # Short Entry: v4 액티브 헤지 숏 필터
        dataframe.loc[
            (
                (dataframe['do_predict'] == 1) &
                (dataframe['DI_ratio'] < di_limit) &
                (dataframe['&-target_roi'] < -prediction_short_threshold_val) & # v4: 0.006 완화
                (dataframe['rsi'] < rsi_short_val) &  # v4: 45 완화
                (dataframe['adx'] > adx_short_val) &  # v4: 22 완화
                (dataframe['fastEMA'] < dataframe['slowEMA']) &
                (dataframe['close'] < dataframe['ema150']) & # v4: ema150 복구
                (dataframe['macdhist'] < 0) # MACD 마이너스 조건 유지
            ),
            'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[
            (dataframe['fastEMA'] < dataframe['slowEMA']),
            'exit_long'] = 1

        dataframe.loc[
            (dataframe['fastEMA'] > dataframe['slowEMA']),
            'exit_short'] = 1

        return dataframe

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        return -0.08

    def _get_df_idx(self, dataframe, target_time) -> int:
        df_dates = pd.to_datetime(dataframe['date']).dt.tz_localize(None)
        target_naive = target_time.replace(tzinfo=None)
        past_candles = df_dates[df_dates <= target_naive - timedelta(hours=4)]
        if not past_candles.empty:
            return past_candles.index[-1]
        return dataframe.index[-1]

    def custom_exit(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> str | bool | None:
        dataframe = GLOBAL_DATAFRAMES.get(pair)
        if dataframe is None or dataframe.empty:
            if self.dp:
                dataframe = self.dp.get_pair_dataframe(pair, self.timeframe)
            if dataframe is None or dataframe.empty:
                return None
        try:
            # 1. 숏 포지션 전용 초고속 이익 보존 장치 (v4 trailing profit exit: 1.5% 되돌림 복원)
            if trade.is_short and trade.highest_profit > 0.035:
                # 수익률이 +3.5% 도달 후 고점 대비 1.5% 이상 되돌릴 때 익절 탈출
                if current_profit < (trade.highest_profit - 0.015):
                    return "short_trailing_profit_exit"

            idx = self._get_df_idx(dataframe, trade.open_date)
            di_ratio = dataframe.loc[idx].get('DI_ratio', 0.0)
            
            # 이더리움 고변동성 롱/숏 비대칭형 dynamic stoploss 설계
            if trade.is_short:
                # 숏은 최대 -6.0%, 최소 -3.0%로 좁고 튼튼한 방어라인 설정
                dynamic_sl = -0.06 + (di_ratio * 0.06)
                dynamic_sl = max(-0.06, min(-0.03, dynamic_sl))
            else:
                # 롱은 변동 노이즈 생존을 위해 최대 -8.0%, 최소 -4.0%로 약간의 공간 확보
                dynamic_sl = -0.08 + (di_ratio * 0.08)
                dynamic_sl = max(-0.08, min(-0.04, dynamic_sl))
            
            if current_profit <= dynamic_sl:
                return "di_continuous_stoploss"
        except Exception as e:
            logger.error(f"Error in custom_exit for V6_Hybrid_Optimized_ETH_v4: {e}")
        return None
